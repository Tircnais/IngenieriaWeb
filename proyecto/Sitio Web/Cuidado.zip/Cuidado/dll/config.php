<?php
    $url_site="http://127.0.0.1/formfactura/";
    $site_name="Sistema registro UTPL";
    $site_factura="FACTURA";
    $site_lista="Lista Registro";

    $user = "root";
    $pass = "";
    $db = "cuidado";
    $host = "127.0.0.1";
    
?>