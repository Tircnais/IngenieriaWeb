package tircnais.lojacuidadocercano;

/**
 * Created by Cristian on 22/03/2017.
 */

public class Constante {
    public static final String servidor = "http://192.168.1.4/";//MI IP
    public static final String proyecto = "Cuidado/";//MI PROYECTO
    public static final String pagina = "";//servidor Charli
    //public static final String ipCtte = "192.168.1.10";//IP home

}
